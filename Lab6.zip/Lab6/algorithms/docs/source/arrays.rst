.. role:: hidden
    :class: hidden-section

algorithms.arrays
=================

.. automodule:: algorithms.arrays
.. currentmodule:: algorithms.arrays

longest_non_repeat
------------------

:hidden:`longest_non_repeat_v1`
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. autofunction:: longest_non_repeat_v1
