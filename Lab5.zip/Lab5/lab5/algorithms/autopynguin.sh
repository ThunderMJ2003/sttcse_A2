for file in $(find algorithms -name "*.py" | sed 's/\.py$//' | tr '/' '.'); do
    echo "Running Pynguin on $file..."
    PYTHONPATH=$(pwd) timeout 30 pynguin --project-path=algorithms --module-name=$file --output-path=generated_tests/$(echo $file | tr '.' '_')
done
